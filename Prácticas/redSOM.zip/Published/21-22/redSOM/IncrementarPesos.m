function W=IncrementarPesos(W,Patron,Vecindad,eta)

for i = size(Patron,1)
    W = W + eta*Vecindad(i,:)*(Patron(i,:)-W);
end

end