function [Gx,Gy]=CalculoGanadora(W,Patron)
[~,x,y] = size(W);



% distEuclidea = sqrt(sum((W(:,1,1)-Patron).^2));

Gx = -1;
Gy = -1;
Hmax = 0;
for i = 1:x
    for j = 1:y
%         dist = sqrt(sum((W(:,j,i)-Patron).^2));
%         if(dist<distEuclidea)
%             distEuclidea = dist;
        theta = sum(W(:,i,j).^2,"all") * 1/2;
        H = W(:,i,j)' * Patron - theta;
        if(H>Hmax)
            Hmax = H;
            Gx = i;
            Gy = j;
        end
    end

end

end

% Cuando usamos la distancia euclídea se nos reduce el tamaño de la red,
% esto se debe a que cuando una gana, el resto de neuronas también se
% actualizan con respecto a la distancia que tienen de la ganadora. Sin
% embargo cuando usamos la matriz de distancias solo se actualizan las
% cercanas con el valor que le hemos dispuesto.

% Si a la función de vecindad ponemos los valores constantes a cero menos
% la ganadora es como usar una red competitiva normal y habrá neuronas que
% no se especialicen.