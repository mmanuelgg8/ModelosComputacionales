function Vecindad = FuncionVecindad(IndGan,W,Indices)
[~,x,y] = size(W);
%Idx = repmat(IndGan,1,x,y);

%dist = reshape(sqrt(sum(Indices - Idx).^2),x,y);
%Vecindad = exp(-dist*100);

V = zeros(x,y);
[i,j] = size(IndGan);

V(i,j) = 1;
if i+1 <= x
    V(i+1,j) = 0.15;
end
if i-1 > 0
    V(i-1,j) = 0.15;
end
if j+1 <= y
    V(i,j+1) = 0.15;
end
if j-1 > 0
    V(i,j-1) = 0.15;
end
Vecindad = V;

end